# ALO AI Whisper – MVP 1.0

## Có gì trong bản này
- PWA cài lên màn hình chính iPhone.
- Chọn nghiệp vụ: vay tiền, mua trả góp, thẩm định.
- Nhập câu khách hàng nói hoặc chọn tình huống mẫu.
- Gợi ý câu hỏi tiếp theo theo bộ quy tắc cục bộ.
- Sao chép gợi ý và đọc bằng giọng tiếng Việt có sẵn trên iPhone.
- Có thể dùng offline sau lần tải đầu tiên.

## Giới hạn quan trọng
Bản MVP này KHÔNG nghe, ghi âm hoặc truy cập âm thanh cuộc gọi di động. iOS không cho PWA thông thường lấy âm thanh cuộc gọi của ứng dụng Điện thoại. Đây là công cụ gợi ý thủ công, không phải AI nghe cuộc gọi trực tiếp. Giọng nữ miền Bắc phụ thuộc giọng tiếng Việt được cài/cung cấp trên iOS; ứng dụng chỉ ưu tiên giọng `vi-VN`, không thể đảm bảo mọi máy có giọng nữ miền Bắc.

## Chạy thử
PWA cần được phục vụ qua HTTPS (hoặc localhost). Không mở `index.html` trực tiếp bằng ứng dụng Files rồi mong cài PWA.

### Cách đơn giản: GitHub Pages
1. Giải nén ZIP.
2. Tạo repository GitHub mới, ví dụ `alo-ai-whisper`.
3. Upload toàn bộ nội dung thư mục này lên nhánh `main`, thư mục gốc.
4. Vào Settings → Pages.
5. Chọn Deploy from a branch → `main` → `/root` → Save.
6. Chờ GitHub Pages cấp địa chỉ HTTPS dạng `https://TEN-TAI-KHOAN.github.io/alo-ai-whisper/`.

### Cài trên iPhone 16 Pro
1. Mở địa chỉ HTTPS bằng Safari.
2. Chạm nút Share.
3. Chọn Add to Home Screen (Thêm vào màn hình chính).
4. Bật Open as Web App nếu tùy chọn xuất hiện.
5. Chạm Add.
6. Mở biểu tượng ALO AI Whisper ngoài màn hình chính.

## Dùng ứng dụng
1. Chọn Vay tiền / Mua trả góp / Thẩm định.
2. Nhập nội dung khách vừa nói hoặc chạm tình huống nhanh.
3. Chạm Phân tích & gợi ý.
4. Đọc gợi ý trên màn hình, hoặc chạm Đọc gợi ý.
5. Kiểm tra âm thanh đang phát ra AirPods trước khi sử dụng trong môi trường tư vấn.

## Cấu trúc
- `index.html`: giao diện
- `styles.css`: giao diện responsive
- `app.js`: logic gợi ý và đọc văn bản
- `manifest.webmanifest`: cấu hình PWA
- `sw.js`: cache/offline
- `icons/`: biểu tượng

## Nâng cấp AI thật
Không đặt API key của OpenAI hoặc nhà cung cấp AI trong `app.js`, vì người khác có thể xem được. Cần backend HTTPS riêng:
- PWA gửi nội dung đã được phép xử lý đến backend.
- Backend xác thực người dùng, giới hạn tốc độ, lọc dữ liệu nhạy cảm.
- Backend gọi mô hình AI và trả về gợi ý ngắn.
- Không lưu nội dung cuộc gọi mặc định.
- Chỉ tích hợp âm thanh cuộc gọi khi có nguồn âm thanh hợp pháp, được thông báo/đồng ý và được nền tảng cho phép.

## An toàn nghiệp vụ
- Không cam kết duyệt vay.
- Không suy đoán CIC hoặc điểm tín dụng.
- Xác minh điều kiện theo chính sách hiện hành của đơn vị tài chính.
- Giải thích lãi, phí, tổng tiền phải trả và nghĩa vụ thanh toán.
- Chỉ thu thập dữ liệu cá nhân cần thiết, đúng mục đích và có căn cứ phù hợp.
