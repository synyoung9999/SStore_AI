const $ = (id) => document.getElementById(id);
let mode = "loan";
let currentSuggestion = "";
const scripts = {
  loan: [
    {keys:["home credit","đang có khoản vay","khoản vay","đang nợ","vay thêm"], type:"KHOẢN VAY HIỆN TẠI", text:"Hỏi khách dư nợ còn lại, số tiền trả hàng tháng và tình trạng thanh toán gần đây. Chưa kết luận đủ điều kiện vay thêm."},
    {keys:["cic","nợ xấu","nhóm nợ"], type:"LỊCH SỬ TÍN DỤNG", text:"Hỏi thời điểm phát sinh, nhóm nợ và tình trạng đã tất toán hay chưa. Chỉ đánh giá sau khi có dữ liệu CIC hợp lệ."},
    {keys:["tự do","không có hợp đồng","freelance"], type:"CÔNG VIỆC", text:"Hỏi công việc cụ thể, thời gian làm, nguồn thu và giấy tờ có thể chứng minh thu nhập."},
    {keys:["50 triệu","vay 50","triệu đồng","muốn vay"], type:"NHU CẦU VAY", text:"Xác nhận số tiền cần vay, mục đích, kỳ hạn mong muốn và khoản trả hàng tháng khách có thể cân đối."},
    {keys:["từ chối","bị từ chối","không duyệt"], type:"HỒ SƠ TỪNG BỊ TỪ CHỐI", text:"Hỏi đơn vị tiếp nhận, thời điểm và lý do từ chối nếu khách biết. Tránh khuyến khích nộp nhiều hồ sơ cùng lúc."}
  ],
  installment: [
    {keys:["trả góp","trả trước","iphone","mua máy","mua điện thoại"], type:"MUA ĐIỆN THOẠI TRẢ GÓP", text:"Hỏi mẫu máy, giá bán, số tiền trả trước và kỳ hạn. Báo rõ tổng số tiền phải trả, lãi và phí trước khi khách quyết định."},
    {keys:["không có hợp đồng","sinh viên","18 tuổi"], type:"ĐIỀU KIỆN KHÁCH HÀNG", text:"Xác minh tuổi, giấy tờ hợp lệ và điều kiện của đơn vị tài chính tại thời điểm đăng ký. Không cam kết chắc chắn được duyệt."}
  ],
  appraisal: [
    {keys:["thu nhập","lương","kiếm được"], type:"XÁC MINH THU NHẬP", text:"Hỏi thu nhập bình quân thực nhận, nguồn thu, tính ổn định và bằng chứng phù hợp."},
    {keys:["địa chỉ","nơi ở","tạm trú"], type:"XÁC MINH NƠI Ở", text:"Xác nhận địa chỉ hiện tại, thời gian cư trú và giấy tờ chứng minh nếu quy trình yêu cầu."},
    {keys:["người thân","gia đình","tham chiếu"], type:"THÔNG TIN THAM CHIẾU", text:"Giải thích mục đích thu thập thông tin tham chiếu và chỉ liên hệ khi có căn cứ, thông báo phù hợp."}
  ]
};
function analyze(text) {
  const value = text.toLowerCase().normalize("NFC");
  const pool = scripts[mode] || scripts.loan;
  const match = pool.find(item => item.keys.some(k => value.includes(k)));
  if (match) return match;
  if (!value.trim()) return {type:"CHƯA CÓ NỘI DUNG",text:"Nhập nội dung khách vừa nói hoặc chọn một tình huống mẫu."};
  if (mode === "installment") return {type:"LÀM RÕ NHU CẦU",text:"Hỏi khách muốn mua mẫu máy nào, ngân sách, khoản trả trước và kỳ hạn dự kiến."};
  if (mode === "appraisal") return {type:"XÁC MINH THÔNG TIN",text:"Hỏi thêm một câu mở để làm rõ công việc, thu nhập, nghĩa vụ tài chính hoặc thông tin còn thiếu."};
  return {type:"LÀM RÕ NHU CẦU",text:"Hỏi mục đích vay, số tiền cần vay, nguồn thu nhập và khả năng trả nợ hàng tháng."};
}
function showResult(result) {
  currentSuggestion = result.text;
  $("resultType").textContent = result.type;
  $("suggestion").textContent = result.text;
  $("copyBtn").disabled = false;
  $("speakBtn").disabled = false;
  if ($("autoSpeak").checked) speak(result.text);
}
function speak(text) {
  if (!("speechSynthesis" in window)) {
    $("voiceInfo").textContent = "Trình duyệt này chưa hỗ trợ đọc văn bản.";
    return;
  }
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "vi-VN";
  utterance.rate = Number($("rate").value);
  const voices = window.speechSynthesis.getVoices();
  const selected = $("voiceSelect").value;
  const voice = voices.find(v => v.name === selected) || voices.find(v => v.lang && v.lang.toLowerCase().startsWith("vi"));
  if (voice) utterance.voice = voice;
  utterance.onstart = () => $("voiceInfo").textContent = "Đang đọc bằng: " + (voice ? voice.name : "giọng mặc định tiếng Việt") + ". Kiểm tra đầu ra âm thanh trước khi sử dụng.";
  utterance.onerror = () => $("voiceInfo").textContent = "Không phát được giọng đọc. Hãy kiểm tra âm lượng và đầu ra âm thanh.";
  window.speechSynthesis.speak(utterance);
}
function loadVoices() {
  const select = $("voiceSelect");
  const old = select.value;
  const voices = window.speechSynthesis ? window.speechSynthesis.getVoices() : [];
  select.innerHTML = '<option value="">Tự động chọn giọng tiếng Việt</option>';
  voices.filter(v => v.lang && v.lang.toLowerCase().startsWith("vi")).forEach(v => {
    const option = document.createElement("option");
    option.value = v.name;
    option.textContent = `${v.name} (${v.lang})`;
    select.appendChild(option);
  });
  if ([...select.options].some(o => o.value === old)) select.value = old;
}
document.querySelectorAll(".tab").forEach(btn => btn.addEventListener("click", () => {
  document.querySelectorAll(".tab").forEach(b => b.classList.toggle("active", b === btn));
  mode = btn.dataset.mode;
}));
document.querySelectorAll(".quick").forEach(btn => btn.addEventListener("click", () => {
  $("customerText").value = btn.dataset.text;
  showResult(analyze(btn.dataset.text));
}));
$("analyzeBtn").addEventListener("click", () => showResult(analyze($("customerText").value)));
$("clearBtn").addEventListener("click", () => {
  $("customerText").value = "";
  $("resultType").textContent = "CHƯA CÓ PHÂN TÍCH";
  $("suggestion").textContent = "Nhập nội dung khách hàng hoặc chọn một tình huống nhanh.";
  currentSuggestion = "";
  $("copyBtn").disabled = $("speakBtn").disabled = true;
});
$("copyBtn").addEventListener("click", async () => {
  try { await navigator.clipboard.writeText(currentSuggestion); $("copyBtn").textContent = "Đã sao chép"; }
  catch { $("suggestion").textContent = currentSuggestion + " (Không sao chép được; hãy chọn và sao chép thủ công.)"; }
});
$("speakBtn").addEventListener("click", () => speak(currentSuggestion));
$("rate").addEventListener("input", e => $("rateValue").textContent = Number(e.target.value).toFixed(2).replace(/0$/,"") + "×");
if (window.speechSynthesis) {
  loadVoices();
  window.speechSynthesis.onvoiceschanged = loadVoices;
}
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").then(() => $("status").textContent = "ĐÃ SẴN SÀNG").catch(() => {}));
}
